<p class="wpo_section ">
    <?php $mb->the_field('link'); ?>
    <label for="seo_title"><?php _e('Link Brand',TEXTDOMAIN); ?>:</label>
    <input type="text" name="<?php $mb->the_name(); ?>" style="width:100%;" value="<?php $mb->the_value(); ?>" />
</p>
